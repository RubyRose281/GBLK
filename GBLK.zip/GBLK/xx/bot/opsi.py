title = raw_input("akses token: ")

limit=10
auto_komen=True
akses_token= title
